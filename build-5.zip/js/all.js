(function(){function r(e,n,t){function o(i,f){if(!n[i]){if(!e[i]){var c="function"==typeof require&&require;if(!f&&c)return c(i,!0);if(u)return u(i,!0);var a=new Error("Cannot find module '"+i+"'");throw a.code="MODULE_NOT_FOUND",a}var p=n[i]={exports:{}};e[i][0].call(p.exports,function(r){var n=e[i][1][r];return o(n||r)},p,p.exports,r,e,n,t)}return n[i].exports}for(var u="function"==typeof require&&require,i=0;i<t.length;i++)o(t[i]);return o}return r})()({1:[function(require,module,exports){
'use strict';

$(document).ready(function () {
    $('#sponsorAction').click(function () {
        $('html,body').animate({ scrollTop: $("#leaderboard").offset().top }, 'slow');
    });
    $('.map-image-wrap').zoom({ url: './img/map-big.jpg' });

    // Sticky Nav
    window.onscroll = function () {
        myFunction();
    };
    // Get the header
    var header = document.getElementById("siteNavTop");
    // Get the offset position of the navbar
    var sticky = header.offsetTop;

    // Add the sticky class to the header when you reach its scroll position. Remove "sticky" when you leave the scroll position
    function myFunction() {
        if (window.pageYOffset > sticky) {
            header.classList.add("sticky");
        } else {
            header.classList.remove("sticky");
        }
    }

    //Profile Image upload
    $(document).on('change', '.form-control-file :file', function () {
        var input = $(this),
            label = input.val().replace(/\\/g, '/').replace(/.*\//, '');
        input.trigger('fileselect', [label]);
    });

    function readURL(input) {
        if (input.files && input.files[0]) {
            var reader = new FileReader();

            reader.onload = function (e) {
                // $('#img-upload').show();
                // $('#img-upload').attr('src', e.target.result);
                $('.profile-image').css('background-image', 'url(' + e.target.result + ')');
                console.log(e.target.result);
            };

            reader.readAsDataURL(input.files[0]);
            $('.fa-user-circle').hide();
        }
    }

    $("#profilePhotoUpload").change(function () {
        readURL(this);
    });

});

},{}]},{},[1]);
